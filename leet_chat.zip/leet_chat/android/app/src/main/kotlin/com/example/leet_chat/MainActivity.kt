package com.example.leet_chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
